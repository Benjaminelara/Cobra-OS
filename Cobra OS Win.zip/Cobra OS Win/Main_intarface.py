from Command_list import get_command_list
from colorama import Fore
from Calculator import calculate, get_about
from Files import get_files, create_file, erase_file, edit, read_file, get_about_files
from snake import snake_game, get_about_snake
from Weather import get_weather



start_calculator = "no"

error = "no"
print(Fore.LIGHTRED_EX + "_  _  _                    _                                                   _  _  _  _      _  _  _  _ ")
print ("_ (*)(*)(*) _                (*)                                                (*(*)(*)(*)   _  _(*)(*)(+)(*)_")
print("(*)         (*)    _  _  _    (+) _  _  _   _       _  _  _  _  _              (+)          (*)(*)          (_)")
print("(*)             _ (*)(*)(*) _ (*)(*)(*)(*)_)      _ (*)(*)(*)(*)(+) _          (*)          (*)(*)_  _  _  _ ")
print("(*)            (*)         (*)(+)        (*) (*)(*)       _  _  _ (*)          (*)          (*)  (*)(*)(*)(*)_")
print("(*)          _ (*)         (*)(*)        (*) (*)        _(*)(*)(_)(_)          (*)          (_) _           (*)")
print("(*) _  _  _ (*)(*) _  _  _ (*)(*) _  _  _(*) (*)       (*)_  _  _ (*)_         (*)_  _  _  _(*)(_)_  _  _  _(*)")
print("  (*)(*)(*)      (*)(*)(*)(*)   (*)(*)(*)(*)   (*)         (*)(*)(*)  (*)         (*)(*)(*)(*)    (*)(*)(*)(*)")
print ("")
print ("VERSION: 1.0.0")
print ("- If you don't know what to do, try typing 'command list'.")
Is_on = True
Location = ["home"]

def get_to(place):
# Calculator -----------------------------------------------------
    if place == "calculator":
        if "calculator" in Location:
            print ("You are already at the calculator")
        else:
            Location.append("calculator")
    elif "calculator" in Location and place == "start":
        calculate()
    elif "calculator" in Location and place == "about":
        get_about()
# ------------------------------------------------------------------

# home ------------------------------------------------------------
    elif place == "home":
        if len(Location) > 1:
            while len(Location) > 1:
                Location.pop()
            print (Fore.LIGHTGREEN_EX + "- You're in home")
        else:
            print ("You are already at home")
    elif "home" in Location and place == "about" and "calculator" not in Location and "snake" not in Location:
        print(Fore.LIGHTRED_EX +  "_  _  _                    _                                                   _  _  _  _      _  _  _  _ ")
        print("_ (*)(*)(*)(*) _                 (*)                                                (*(*)(*)(*)   _  _(*)(*)(+)(*)_")
        print("(*)         (*)    _  _  _    (+) _  _  _   _       _  _  _  _  _              (+)          (*)(*)          (_)")
        print("(*)             _ (*)(*)(*) _ (*)(*)(*)(*)_)      _ (*)(*)(*)(*)(+) _          (*)          (*)(*)_  _  _  _ ")
        print("(*)            (*)         (*)(+)        (*) (*)(*)       _  _  _ (*)          (*)          (*)  (*)(*)(*)(*)_")
        print("(*)          _ (*)         (*)(*)        (*) (*)        _(*)(*)(_)(_)          (*)          (_) _           (*)")
        print("(*) _  _  _ (*)(*) _  _  _ (*)(*) _  _  _(*) (*)       (*)_  _  _ (*)_         (*)_  _  _  _(*)(_)_  _  _  _(*)")
        print("  (*)(*)(*)      (*)(*)(*)(*)   (*)(*)(*)(*)   (*)         (*)(*)(*)  (*)         (*)(*)(*)(*)    (*)(*)(*)(*)")
        print("")
        print("VERSION: 1.0.0")
        print ("")
        print ( Fore.LIGHTWHITE_EX + "- Cobra OS is an Linux and MS DOS inspired operating system made in python, with some GUI")
        print ("- apps for the sake of the programmers, and the user.")
        print ("- This hasn't got any real use, but I thought it would be fun to build the project.")
        print ("- Luckily, the OS is open-source, so you can see the code, modify it, and even learn from it!")
        print ("- the OS is not encrypted or built for security, so you might")
        print ("- want to keep your sensitive information AWAY from the main program and all its apps.")
        print ("- If you want to contribute, or need MORE INFO, you can check out the Github page: https://github.com/Benjaminelara/Cobra-OS")
        print ("- Thank you for using Cobra OS!")
        print ("")
        print ("- Benjamin Lara")


# --------------------------------------------------------------------

    elif place == "command list":
        get_command_list()
# Files ---------------------------------------------------------------
    elif place == "files" and "calculator" not in Location and "snake" not in Location:
        if "files" in Location:
            print(Fore.LIGHTGREEN_EX + "- You are already in files")
        else:
            Location.append("files")
    elif place == "list" and "files" in Location:
        get_files()
    elif place == "new" and "files" in Location:
        create_file()
    elif place == "delete" and "files" in Location:
        erase_file()
    elif place == "edit" and "files" in Location:
        edit()
    elif place == "read" and "files" in Location:
        read_file()
    elif place == "about" and "files" in Location:
        get_about_files()


#snake -----------------------------------------------------------------

    elif place == "snake" and "calculator" not in Location and "files" not in Location:
        if "snake" in Location:
            print(Fore.LIGHTGREEN_EX + "- You are already in snake")
        else:
            Location.append("snake")
            print(Fore.LIGHTMAGENTA_EX + "                                 d8b                          ")
            print("                                 ?88                          ")
            print("                                  88b                 ")
            print(" .d888b,  88bd88b    d888b8b      888  d88' d8888b")
            print(" ?8b,     88P' ?8b   8P' ?88      888bd8P' d8b_,dP")
            print("   `?8b  d88   88P  88b  ,88b    d88888b   88b    ")
            print("`?888P' d88'   88b  `?88P'`88b  d88' `?88b, `?888P'")
            print("")
            print("type start to play!")
            print("")
            print(Fore.LIGHTWHITE_EX + "Snake Game Rules:")
            print(Fore.LIGHTGREEN_EX + "Objective:" + Fore.LIGHTWHITE_EX + "Guide the snake to eat food pellets (usually red) that appear on the screen.")

            print(Fore.LIGHTGREEN_EX + "Movement:" + Fore.LIGHTWHITE_EX + "Use arrow keys (up, down, left, right) to control the snake's direction.")

            print(Fore.LIGHTGREEN_EX + "Growth:" + Fore.LIGHTWHITE_EX + "Each time the snake eats a food pellet, it grows longer by one block.")

            print(Fore.LIGHTGREEN_EX + "Boundaries:" + Fore.LIGHTWHITE_EX + "The game ends if the snake hits the edge of the screen.")

            print(Fore.LIGHTGREEN_EX+ "Self-Collision:" + Fore.LIGHTWHITE_EX + "If the snake runs into its own body, the game ends.")

            print(Fore.LIGHTGREEN_EX + "Scorekeeping:" + Fore.LIGHTWHITE_EX + "The score increases with each food pellet consumed.")
    elif place == "start" and "snake" in Location:
        snake_game()
    elif place == "about" and "snake" in Location:
        get_about_snake()
#-----------------------------------------------------------------------------------------------------------------------------
    elif place == "weather":
        get_weather()










    else:
        print(Fore.LIGHTGREEN_EX + f"- {place} was not found, try again")


while Is_on:
    where_to_go = input(Fore.LIGHTWHITE_EX + f"{Location}:")
    if "home" in Location and "calculator" not in Location and "files" not in Location and "snake" not in Location and where_to_go == "exit":
        break
    else:
        get_to(where_to_go)

import requests
def get_weather():
    requested_city = input("- Enter your city name: ")
    content = requests.get(f"https://wttr.in/{requested_city}")
    print(content.text)

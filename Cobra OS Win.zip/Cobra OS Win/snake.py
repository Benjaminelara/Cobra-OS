import pygame
import random
from colorama import Fore


def snake_game():
    # Initialize Pygame
    pygame.init()
    pygame.mixer.init()

    # Set up the game window
    width = 800
    height = 600
    window = pygame.display.set_mode((width, height))
    pygame.display.set_caption("Snake Game")

    # Colors
    BLACK = (0, 0, 0)
    WHITE = (255, 255, 255)
    RED = (255, 0, 0)
    GREEN = (0, 255, 0)
    YELLOW = (255, 255, 0)

    # Snake properties
    snake_block = 20
    snake_inner = 18  # Size of the inner block
    snake_speed = 12

    # Initialize clock
    clock = pygame.time.Clock()

    # Font for score display
    font = pygame.font.SysFont(None, 35)

    # Sound effects
    eat_sound = pygame.mixer.Sound("eat.mp3")
    crash_sound = pygame.mixer.Sound("explode.mp3")

    def draw_snake(snake_block, snake_inner, snake_list):
        for i, block in enumerate(snake_list):
            if i == len(snake_list) - 1:  # The last block is the head
                pygame.draw.rect(window, YELLOW, [block[0] + 1, block[1] + 1, snake_inner, snake_inner])
            else:  # The rest of the body is green
                pygame.draw.rect(window, GREEN, [block[0] + 1, block[1] + 1, snake_inner, snake_inner])

    def gameLoop():
        game_over = False

        x1 = width / 2
        y1 = height / 2

        x1_change = 0
        y1_change = 0

        direction = None  # Track current direction ('UP', 'DOWN', 'LEFT', 'RIGHT')
        snake_list = []
        length_of_snake = 1

        foodx = round(random.randrange(0, width - snake_block) / 20.0) * 20.0
        foody = round(random.randrange(0, height - snake_block) / 20.0) * 20.0

        while not game_over:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    game_over = True
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_LEFT and direction != 'RIGHT':  # Prevent turning into itself
                        x1_change = -snake_block
                        y1_change = 0
                        direction = 'LEFT'
                    elif event.key == pygame.K_RIGHT and direction != 'LEFT':
                        x1_change = snake_block
                        y1_change = 0
                        direction = 'RIGHT'
                    elif event.key == pygame.K_UP and direction != 'DOWN':
                        y1_change = -snake_block
                        x1_change = 0
                        direction = 'UP'
                    elif event.key == pygame.K_DOWN and direction != 'UP':
                        y1_change = snake_block
                        x1_change = 0
                        direction = 'DOWN'

            if x1 >= width or x1 < 0 or y1 >= height or y1 < 0:
                game_over = True
                crash_sound.play()

            x1 += x1_change
            y1 += y1_change
            window.fill(BLACK)
            pygame.draw.rect(window, RED, [foodx, foody, snake_block, snake_block])
            snake_head = [x1, y1]
            snake_list.append(snake_head)

            if len(snake_list) > length_of_snake:
                del snake_list[0]

            for block in snake_list[:-1]:
                if block == snake_head:
                    game_over = True
                    crash_sound.play()


            draw_snake(snake_block, snake_inner, snake_list)

            # Display score
            score = font.render("Score: " + str(length_of_snake - 1), True, WHITE)
            window.blit(score, [1, 0])
            with open("High_score", "r") as f:
                high_score = int(f.read())

            High_score = font.render(f"High score: {high_score}", True, WHITE)
            window.blit(High_score, [1, 25])


            pygame.display.update()

            if x1 == foodx and y1 == foody:
                foodx = round(random.randrange(0, width - snake_block) / 20.0) * 20.0
                foody = round(random.randrange(0, height - snake_block) / 20.0) * 20.0
                length_of_snake += 1
                eat_sound.play()

            clock.tick(snake_speed)




        if high_score < length_of_snake - 1:
            with open("High_score", "w") as f:
                f.write(str(length_of_snake - 1))
        pygame.time.wait(1000)
        pygame.quit()
        print("")
        print(Fore.LIGHTGREEN_EX + f"- Game over! your score was of {str(length_of_snake - 1)} ")
        print("")


    gameLoop()



def get_about_snake():
    print(Fore.LIGHTMAGENTA_EX + "                                 d8b                          ")
    print("                                 ?88                          ")
    print("                                  88b                 ")
    print(" .d888b,  88bd88b    d888b8b      888  d88' d8888b")
    print(" ?8b,     88P' ?8b   8P' ?88      888bd8P' d8b_,dP")
    print("   `?8b  d88   88P  88b  ,88b    d88888b   88b    ")
    print("`?888P' d88'   88b  `?88P'`88b  d88' `?88b, `?888P'")
    print("")
    print("- VERSION: 1.0 BY: Benjamin Lara")
    print("")
    print(Fore.LIGHTWHITE_EX + "- This is a very simple yet fun game about a snake who needs to eat pellets.")
    print("- The game is based on the original snake game in the old Nokia devices")
    print("- For more information head to the github page: https://github.com/Benjaminelara/Cobra-OS")
    print("- Thanks for playing snake!")


from colorama import Fore
import os
import re
from datetime import datetime
import tkinter as tk
from tkinter import messagebox
from tkinter import scrolledtext

def get_files():
    with open("files_ID", "r") as f:
        files = f.readlines()
        number_of_files = len(files)
        if number_of_files <= 0:
            print("")
            print(Fore.LIGHTGREEN_EX + "- You have currently no files, use 'new' to create a .txt file.")
            print("")
        else:
            print("")
            print(Fore.LIGHTGREEN_EX + f"{number_of_files} files detected")
            print("")
            print("Name             Date")
            print("")

            for file in files:
                print(Fore.LIGHTWHITE_EX + file)
            print("")
    return files

def create_file():

    date = datetime.now()
    name_of_file = input(Fore.LIGHTWHITE_EX + "['home', 'files', 'file name']:")

    with open("files_ID", "a") as f:
            f.writelines(f"{name_of_file}            {date} \n")

    open(name_of_file, "x")

def erase_file():
    list_number = -1
    with open("files_ID", "r") as f:
        files = f.readlines()
    print("")
    for file in files:
        list_number += 1
        print(list_number, file)
    print(Fore.LIGHTGREEN_EX + "- Select the file (0,1,2...) you want to erase")
    print("")
    wanted_dead = int(input(Fore.LIGHTWHITE_EX + "['home', 'files', 'delete']:"))
# Search file name
    string = files[wanted_dead]
    pattern = "..................."
    result = (re.search(pattern, string))
    cachimba = str(result.group())
    cachimba = cachimba.split()
    cachimba = cachimba[0]
    confirmation = input(Fore.LIGHTRED_EX + f"- Are you sure you want to delete '{cachimba}.txt'? y/n :")
    if confirmation.lower() == "y":
        os.remove(cachimba)
        files.pop(wanted_dead)
        with open("files_ID", "w") as f:
            f.writelines(files)
    else:
        pass

def read_file():
    file_number = -1
    # Show available files
    with open("files_ID", "r") as f:
        files = f.readlines()
    print("")
    for file in files:
        file_number += 1
        print(file_number, file.strip())
    print("")
    print("")
    print(Fore.LIGHTGREEN_EX + "- Select the file (0,1,2...) you want to read")
    print("")

    file_to_read = int(input(Fore.LIGHTWHITE_EX + "['home', 'files', 'read']:"))
    try:
        string = files[file_to_read]
        pattern = "..................."
        result = (re.search(pattern, string))
        cachimba = str(result.group())
        cachimba = cachimba.split()
        cachimba = cachimba[0]
        with open(cachimba, "r") as f:
            content = f.read()
            print("")
            print(Fore.LIGHTWHITE_EX + content)
            print("")
    except FileNotFoundError:
        print(Fore.LIGHTRED_EX + f"- Error: File '{file_to_read}' not found")


def edit():
    # Initialize current_file as a global variable
    global current_file
    current_file = None

    # Create the main window
    editor = tk.Tk()
    editor.title('Cobra OS Text Editor')
    editor.geometry('1000x600')  # Increased width to accommodate file list

    # Create a frame to hold the file list and text area
    main_frame = tk.Frame(editor)
    main_frame.pack(fill='both', expand=True)

    # Create file list frame
    file_frame = tk.Frame(main_frame, width=200)
    file_frame.pack(side='left', fill='y', padx=5)

    # Create file list scrollbar
    file_scroll = tk.Scrollbar(file_frame)
    file_scroll.pack(side='right', fill='y')

    # Create file list
    file_list = tk.Listbox(file_frame, width=30, yscrollcommand=file_scroll.set)
    file_list.pack(fill='y', expand=True)
    file_scroll.config(command=file_list.yview)

    # Populate file list
    def populate_file_list():
        file_list.delete(0, tk.END)
        with open('files_ID', 'r') as f:
            files = f.readlines()
        for file in files:
            file_list.insert(tk.END, file.strip())

    # Create text area frame
    text_frame = tk.Frame(main_frame)
    text_frame.pack(side='right', fill='both', expand=True)

    # Create text area with scrollbar
    text_scroll = tk.Scrollbar(text_frame)
    text_scroll.pack(side='right', fill='y')

    text_area = scrolledtext.ScrolledText(text_frame, wrap=tk.WORD, width=80, height=30,
                                         yscrollcommand=text_scroll.set)
    text_area.pack(fill='both', expand=True)
    text_scroll.config(command=text_area.yview)

    def save_file():
        if current_file:
            try:
                with open(current_file, 'w') as file:
                    file.write(text_area.get('1.0', tk.END))
                messagebox.showinfo('Success', 'File saved successfully!')
            except Exception as e:
                messagebox.showerror('Error', f'Error saving file: {str(e)}')
        else:
            messagebox.showerror('Error', 'No file is currently open')

    def open_file(event=None):
        selected_index = file_list.curselection()
        if selected_index:
            file_entry = file_list.get(selected_index)
            filename = file_entry.split()[0]
            try:
                with open(filename, 'r') as file:
                    content = file.read()
                    text_area.delete('1.0', tk.END)
                    text_area.insert('1.0', content)
                    global current_file
                    current_file = filename
                    editor.title(f'Cobra OS Text Editor - {filename}')
            except Exception as e:
                messagebox.showerror('Error', f'Error loading file: {str(e)}')

    def get_version():
        messagebox.showinfo('Info', 'Version: 1.0.0')

    def get_about():
        messagebox.showinfo('Info', 'The CobraOS Text Editor:\n\nCreated by: Benjamin Lara\n\n This is a simple text editor made in python, with tkinter for the GUI.\n\n')

    # Create menu bar
    menu_bar = tk.Menu(editor)
    editor.config(menu=menu_bar)

    # File menu
    file_menu = tk.Menu(menu_bar, tearoff=0)
    menu_bar.add_cascade(label='File', menu=file_menu)
    file_menu.add_command(label='Save', command=save_file)
    file_menu.add_command(label='Refresh Files', command=populate_file_list)

    # Info menu
    info_menu = tk.Menu(menu_bar, tearoff=0)
    menu_bar.add_cascade(label='Info', menu=info_menu)
    info_menu.add_command(label='Version', command=get_version)
    info_menu.add_command(label='About', command=get_about)

    # Bind double-click to open file
    file_list.bind('<Double-1>', open_file)

    # Populate the file list initially
    populate_file_list()

    # Start the editor
    editor.mainloop()

def get_about_files():

    print(Fore.LIGHTCYAN_EX + "            :::::::::: ::::::::::: :::        :::::::::: ::::::::")
    print("         :+:            :+:     :+:        :+:       :+:    :+:")
    print("        +:+            +:+     +:+        +:+       +:+         ")
    print("      :#::+::#       +#+     +#+        +#++:++#  +#++:++#++   ")
    print("   +#+            +#+     +#+        +#+              +#+    ")
    print("  #+#            #+#     #+#        #+#       #+#    #+#     ")
    print("###        ########### ########## ########## ########       ")
    print("Version 1.0 by Benjamin Lara")
    print("")
    print(Fore.LIGHTWHITE_EX + "- This is a complete files app, letting you")
    print("- Create, edit, read, and delete a file")
    print("- For more info Head to the Github page: https://github.com/Benjaminelara/Cobra-OS")

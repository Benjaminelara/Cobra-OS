from colorama import Fore
def get_command_list():
    print (Fore.LIGHTGREEN_EX +"- 'about': when typed, this command displays info of the place you are currently in.")
    print ("- 'exit': in the home tab, you can leave the OS by typing it.")
    print ("- 'calculator: it gets you to the calculator.")
    print ("- 'home': it gets you to the home tab.")
    print ("- 'start': it starts the app you are currently in (mind that it only works on apps, not in the home page).")
    print ("- 'command list': if you are here it means you know what is this for.")
    print ("- 'snake': lets you play the snake game.")
    print ("- If you have any further problems with the OS, make sure to read the documentation in (github page)")

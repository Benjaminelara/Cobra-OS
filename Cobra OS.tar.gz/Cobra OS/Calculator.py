

error = "no"
from colorama import Fore


def calculate():
        first_number = (input("['home', 'calculator', 'first number']:"))
        try:
            float(first_number)
        except:
            raise(ValueError("- The first number is not a number"))
        else:
            first_number = float(first_number)



        while True:
                operator = input(Fore.LIGHTWHITE_EX + "['home', 'calculator', 'operator']:")
                if operator in ["*", "+", "-", "/"]:
                    break
                else:
                    print(Fore.LIGHTGREEN_EX + "- The entered operator is incorrect, try again")

        second_number = (input(Fore.LIGHTWHITE_EX + "['home', 'calculator', 'second number']:"))
        try:
            float(second_number)
        except:
            raise(ValueError("- The second number is not a number"))
        else:
            second_number = float(second_number)

        if operator == "*":
            result = first_number * second_number
        elif operator == "+":
            result = first_number + second_number
        elif operator == "-":
            result = first_number - second_number
        elif operator == "/":
            result = first_number / second_number

        want_second = input(Fore.LIGHTGREEN_EX + "- Do you want to add a second operator? y/n_")
        if want_second.lower() == "y":
            while True:
                second_operator = input(Fore.LIGHTWHITE_EX + "['home', 'calculator', 'second operator']:")
                if second_operator in ["*", "+", "-", "/"]:
                    break
                else:
                    print(Fore.LIGHTYELLOW_EX + "- The entered second operator is incorrect, try again")

            third_number = float(input(Fore.LIGHTWHITE_EX + "['home', 'calculator', 'third number']:"))

            # Multiplication combinations
            if operator == "*" and second_operator == "*":
                result = first_number * second_number * third_number
            elif operator == "*" and second_operator == "+":
                result = first_number * second_number + third_number
            elif operator == "*" and second_operator == "-":
                result = first_number * second_number - third_number
            elif operator == "*" and second_operator == "/":
                result = first_number * second_number / third_number

            # Addition combinations
            elif operator == "+" and second_operator == "*":
                result = first_number + second_number * third_number
            elif operator == "+" and second_operator == "+":
                result = first_number + second_number + third_number
            elif operator == "+" and second_operator == "-":
                result = first_number + second_number - third_number
            elif operator == "+" and second_operator == "/":
                result = first_number + second_number / third_number

            # Subtraction combinations
            elif operator == "-" and second_operator == "*":
                result = first_number - second_number * third_number
            elif operator == "-" and second_operator == "+":
                result = first_number - second_number + third_number
            elif operator == "-" and second_operator == "-":
                result = first_number - second_number - third_number
            elif operator == "-" and second_operator == "/":
                result = first_number - second_number / third_number

            # Division combinations
            elif operator == "/" and second_operator == "*":
                result = first_number / second_number * third_number
            elif operator == "/" and second_operator == "+":
                result = first_number / second_number + third_number
            elif operator == "/" and second_operator == "-":
                result = first_number / second_number - third_number
            elif operator == "/" and second_operator == "/":
                result = first_number / second_number / third_number

        print(Fore. LIGHTYELLOW_EX + f"- The result is {result}")

def get_about():

    print(Fore.LIGHTYELLOW_EX + " _______  _______  ___      _______  __   __  ___      _______  _______  _______  ______")
    print("|       ||   _   ||   |    |       ||  | |  ||   |    |   _   ||       ||       ||    _ |")
    print("|       ||  |_|  ||   |    |       ||  | |  ||   |    |  |_|  ||_     _||   _   ||   | ||")
    print("|       ||       ||   |    |       ||  |_|  ||   |    |       |  |   |  |  | |  ||   |_||_")
    print("|      _||       ||   |___ |      _||       ||   |___ |       |  |   |  |  |_|  ||    __  |")
    print("|     |_ |   _   ||       ||     |_ |       ||       ||   _   |  |   |  |       ||   |  | |")
    print("|_______||__| |__||_______||_______||_______||_______||__| |__|  |___|  |_______||___|  |_|")
    print("")
    print("VERSION: 1.0, BY: Benjamin Lara")
    print("")
    print(Fore.LIGHTWHITE_EX + "- This is a simple, kinda fast, calculator app. It supports additions, subtractions, multiplications, and divisions.")
    print("- For more info head to https://github.com/Benjaminelara/Cobra-OS")
